package com.BankLoanManagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankLoanManagementApplication {

	public static void main(String[] args) {
		//application context, server 
		SpringApplication.run(BankLoanManagementApplication.class, args);
		System.out.println("Bank Loan Management Application Started...");
	}
}
