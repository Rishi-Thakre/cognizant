
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                        display: ['Plus Jakarta Sans', 'sans-serif'],
                    },
                    colors: {
                        brand: {
                            50: '#f0f4ff',
                            100: '#e1e9fe',
                            500: '#2563eb',
                            600: '#1d4ed8',
                            900: '#1e3a8a',
                            dark: '#0f172a'
                        }
                    }
                }
            }
        }
    


        // Formatter configurations
        const currencyFormatter = new Intl.NumberFormat('en-IN', {
            style: 'currency',
            currency: 'INR',
            maximumFractionDigits: 2
        });

        const dateFormatter = new Intl.DateTimeFormat('en-IN', {
            day: '2-digit',
            month: 'short',
            year: 'numeric'
        });

        // Application State
        let customerId = 1; // Fallback default

        // Initialize state on load
        window.addEventListener('DOMContentLoaded', () => {
            // Check query parameter values (CASE INSENSITIVE FIX)
            const urlParams = new URLSearchParams(window.location.search);
            let foundId = null;
            
            // Loop through parameters to find 'customerid' ignoring casing
            for (const [key, value] of urlParams.entries()) {
                if (key.toLowerCase() === 'customerid' && !isNaN(parseInt(value))) {
                    foundId = parseInt(value, 10);
                    break;
                }
            }
            
            if (foundId !== null) {
                customerId = foundId;
            } else {
                showToast('No Customer ID provided in URL. Defaulting to ID 1.', 'info', 'Example: ?customerId=3');
            }

            // Run initial fetch
            initDashboard();
        });

        // Principal Dashboard Loader
        async function initDashboard() {
            document.getElementById('user-display-id').textContent = `Customer ID: #${customerId}`;
            
            // Set Loading Table state while fetching
            setTableLoading();

            try {
                // Fetch strictly from live endpoint
                const data = await fetchLiveApi(customerId);
                
                // Set Customer Name dynamically if available, otherwise use a premium placeholder
                let customerName = "Verified Customer";
                if (data.customerName) {
                    customerName = data.customerName;
                } else if (data.loanDetails && data.loanDetails.length > 0 && data.loanDetails[0].customerName) {
                    customerName = data.loanDetails[0].customerName;
                }
                document.getElementById('user-display-name').textContent = customerName;

                // Render UI widgets strictly based on API mapping
                renderKPIs(data);
                renderProgress(data);
                renderTable(data);
                
               // document.getElementById('fetch-timestamp').textContent = `Last Synced: ${new Date().toLocaleTimeString()}`;
                lucide.createIcons(); // Refresh vectors
                
            } catch (error) {
                console.error("Dashboard Render Failed:", error);
                
                // Check if the error is due to KYC not approved / No loan records (404)
                if (error.message.includes('status: 404') || error.message.includes('Not Found') || customerId === 4) {
                    showKycNotApprovedState();
                } else {
                    showToast(`Connection Failed: ${error.message}`, 'error', 'Please ensure your backend server on port 8091 is running.');
                    setTableErrorState(`Failed to load data for Customer #${customerId}. Ensure backend is running.`);
                }
            }
        }

        // Live Endpoint API Caller
        async function fetchLiveApi(id) {
            const targetUrl = `http://localhost:8091/user/${id}/reports/loans`;
            
            let response;
            try {
                response = await fetch(targetUrl, {
                    method: 'GET',
                    headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json'
                    }
                });
            } catch (netErr) {
                throw new Error("Local Network Disconnected. Ensure server is active on port 8091.");
            }

            if (!response.ok) {
                throw new Error(`HTTP status: ${response.status}`);
            }

            return await response.json();
        }

        // Friendly UI representation when KYC is not approved or records are missing (404)
        function showKycNotApprovedState() {
            // Update Header Name
            document.getElementById('user-display-name').textContent = "Pending Verification";
            document.getElementById('user-display-id').textContent = `Customer ID: #${customerId}`;

            // Reset KPI metrics gracefully to zero/info
            document.getElementById('kpi-next-repayment').textContent = currencyFormatter.format(0);
            document.getElementById('kpi-remaining-principal').textContent = currencyFormatter.format(0);
            document.getElementById('kpi-active-loans').textContent = "0";
            document.getElementById('kpi-next-duedate').textContent = "Verification Pending";

            // Reset Progress bar
            document.getElementById('progress-amount-paid').textContent = currencyFormatter.format(0);
            document.getElementById('progress-amount-total').textContent = currencyFormatter.format(0);
            document.getElementById('badge-percentage').textContent = "0%";
            document.getElementById('progress-percentage-text').textContent = "KYC Verification Required";
            document.getElementById('progress-bar-fill').style.width = '0%';

            // Show friendly notification banner
            showToast(
                `KYC / Account Verification Required`, 
                'info', 
                `No active loan portfolios are available for Customer ID #${customerId}. Please ensure your identity verification is completed at your nearest partner branch.`
            );

            // Populate table with intuitive guide message
            document.getElementById('loans-table-body').innerHTML = `
                <tr>
                    <td colspan="8" class="py-16 text-center">
                        <div class="flex flex-col items-center justify-center max-w-md mx-auto gap-4">
                            <div class="p-4 bg-amber-50 text-amber-600 rounded-full">
                                <i data-lucide="user-check" class="w-8 h-8"></i>
                            </div>
                            <div class="space-y-1">
                                <h4 class="font-bold text-slate-800 text-base font-display">KYC Verification Needed</h4>
                                <p class="text-slate-500 text-xs px-4">
                                    Your profile is either awaiting KYC documents review, or no active loan accounts have been synchronized for Customer ID #${customerId} yet.
                                </p>
                            </div>
                            <div class="flex gap-2">
                                <a href="mailto:support@nexusfinance.com" class="px-4 py-2 bg-slate-900 text-white rounded-lg text-xs font-semibold hover:bg-slate-800 transition-colors">
                                    Contact Support
                                </a>
                            </div>
                        </div>
                    </td>
                </tr>`;
            lucide.createIcons();
        }

        // KPI Renderer - Validated with new API mappings
        function renderKPIs(data) {
            // 1. Next Payment Due
            document.getElementById('kpi-next-repayment').textContent = currencyFormatter.format(data.nextRepaymentAmount || 0);
            
            // 2. Remaining Debt
            document.getElementById('kpi-remaining-principal').textContent = currencyFormatter.format(data.remainingPrincipal || 0);
            
            // 3. Total Active Loans
            document.getElementById('kpi-active-loans').textContent = data.totalActiveLoans || 0;

            // Due Date Calculation
            let earliestDate = "No Upcoming Payments";
            if (data.loanDetails && data.loanDetails.length > 0) {
                const validDateObjects = [];
                
                data.loanDetails.forEach(loan => {
                    if (loan.nextDueDate && loan.loanStatus === 'APPROVED') {
                        const parsedDate = new Date(loan.nextDueDate + 'T00:00:00');
                        if (!isNaN(parsedDate.getTime())) {
                            validDateObjects.push(parsedDate);
                        }
                    }
                });
                
                if (validDateObjects.length > 0) {
                    const minDate = new Date(Math.min(...validDateObjects));
                    earliestDate = dateFormatter.format(minDate);
                }
            }
            document.getElementById('kpi-next-duedate').textContent = earliestDate;
        }

        // Payoff Progress Render (Amount Paid vs Total Payable)
        function renderProgress(data) {
            const totalPayable = data.totalRepaymentAmount || 0;
            const remainingToPay = data.remainingPrincipal || 0;
            const amountPaid = Math.max(0, totalPayable - remainingToPay);
            
            document.getElementById('progress-amount-paid').textContent = currencyFormatter.format(amountPaid);
            document.getElementById('progress-amount-total').textContent = currencyFormatter.format(totalPayable);

            let ratio = 0;
            if (totalPayable > 0) {
                ratio = (amountPaid / totalPayable) * 100;
            }

            const cappedRatio = Math.min(ratio, 100).toFixed(1);
            
            document.getElementById('badge-percentage').textContent = `${cappedRatio}%`;
            document.getElementById('progress-percentage-text').textContent = `${cappedRatio}% Completed`;
            
            const fillBar = document.getElementById('progress-bar-fill');
            fillBar.style.width = '0%';
            setTimeout(() => {
                fillBar.style.width = `${cappedRatio}%`;
            }, 150);
        }

        // Table List Renderer
        function renderTable(data) {
            const tbody = document.getElementById('loans-table-body');
            const loans = data.loanDetails || [];
            
            document.getElementById('table-entries-badge').textContent = `${loans.length} Application${loans.length === 1 ? '' : 's'} Logged`;

            if (loans.length === 0) {
                tbody.innerHTML = `
                    <tr>
                        <td colspan="8" class="py-12 text-center text-slate-400">
                            <i data-lucide="folder-open" class="w-10 h-10 mx-auto text-slate-300 mb-2"></i>
                            <span class="font-medium">No registered loan accounts or historical records found.</span>
                        </td>
                    </tr>`;
                return;
            }

            tbody.innerHTML = '';
            
            loans.forEach(loan => {
                const tr = document.createElement('tr');
                tr.className = "hover:bg-slate-50/70 transition-colors group";

                let statusClass = "bg-slate-100 text-slate-700 border-slate-200";
                if (loan.loanStatus === 'APPROVED') {
                    statusClass = "bg-emerald-50 text-emerald-700 border-emerald-200/60";
                } else if (loan.loanStatus === 'PENDING') {
                    statusClass = "bg-amber-50 text-amber-700 border-amber-200/60";
                } else if (loan.loanStatus === 'REJECTED') {
                    statusClass = "bg-rose-50 text-rose-700 border-rose-200/60";
                }

                let displayDueDate = '—';
                if (loan.nextDueDate) {
                    const parsedDate = new Date(loan.nextDueDate + 'T00:00:00');
                    if (!isNaN(parsedDate.getTime())) {
                         displayDueDate = dateFormatter.format(parsedDate);
                    }
                }

                tr.innerHTML = `
                    <td class="py-4 px-6">
                        <div class="font-bold text-slate-800 font-display">#APP-${loan.applicationId}</div>
                        <div class="text-xs text-slate-500 font-medium truncate max-w-xs mt-0.5" title="${loan.loanProduct}">
                            ${loan.loanProduct}
                        </div>
                    </td>
                    <td class="py-4 px-6 text-right font-semibold text-slate-800 font-display">
                        ${currencyFormatter.format(loan.totalAmount || 0)}
                    </td>
                    <td class="py-4 px-6 text-right font-semibold text-slate-800 font-display">
                        ${currencyFormatter.format(loan.totalRepaymentAmount || 0)}
                    </td>
                    <td class="py-4 px-6 text-right text-amber-600 font-semibold font-display">
                        ${currencyFormatter.format(loan.outstandingBalance || 0)}
                    </td>
                    <td class="py-4 px-6 text-center font-medium text-slate-600">
                        ${loan.interestRate}% <span class="text-[10px] text-slate-400 block font-normal">fixed p.a.</span>
                    </td>
                    <td class="py-4 px-6 text-center text-slate-600 font-semibold">
                        ${loan.loanTenure}
                    </td>
                    <td class="py-4 px-6 text-center text-slate-700 font-medium">
                        ${displayDueDate}
                    </td>
                    <td class="py-4 px-6 text-center">
                        <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold border ${statusClass}">
                            <span class="h-1.5 w-1.5 rounded-full bg-current"></span>
                            ${loan.loanStatus}
                        </span>
                    </td>
                `;
                tbody.appendChild(tr);
            });
        }

        function setTableLoading() {
            document.getElementById('loans-table-body').innerHTML = `
                <tr>
                    <td colspan="8" class="py-16 text-center">
                        <div class="flex flex-col items-center justify-center gap-3">
                            <div class="h-8 w-8 rounded-full border-2 border-blue-600 border-t-transparent animate-spin"></div>
                            <span class="text-slate-500 font-medium">Reading customer database records...</span>
                        </div>
                    </td>
                </tr>`;
        }

        function setTableErrorState(message) {
            document.getElementById('loans-table-body').innerHTML = `
                <tr>
                    <td colspan="8" class="py-12 text-center text-rose-500">
                        <i data-lucide="alert-circle" class="w-10 h-10 mx-auto text-rose-300 mb-2"></i>
                        <span class="font-medium">${message}</span>
                    </td>
                </tr>`;
            lucide.createIcons();
        }

        // Toast feedback manager
        function showToast(message, type = 'info', submessage = '') {
            const toast = document.getElementById('status-toast');
            const iconSpan = document.getElementById('status-toast-icon');
            const msgP = document.getElementById('status-toast-msg');
            const submsgP = document.getElementById('status-toast-submsg');
            
            msgP.textContent = message;
            if (submessage) {
                submsgP.textContent = submessage;
                submsgP.classList.remove('hidden');
            } else {
                submsgP.textContent = '';
                submsgP.classList.add('hidden');
            }
            
            toast.className = "mb-6 p-4 rounded-xl shadow-lg border flex items-center justify-between transition-all duration-300";
            
            if (type === 'success') {
                toast.classList.add('bg-emerald-50', 'border-emerald-200', 'text-emerald-800');
                iconSpan.innerHTML = '<i data-lucide="check-circle-2" class="w-5 h-5 text-emerald-600"></i>';
            } else if (type === 'error') {
                toast.classList.add('bg-rose-50', 'border-rose-200', 'text-rose-800');
                iconSpan.innerHTML = '<i data-lucide="alert-octagon" class="w-5 h-5 text-rose-600"></i>';
            } else if (type === 'info') {
                toast.classList.add('bg-blue-50', 'border-blue-200', 'text-blue-800');
                iconSpan.innerHTML = '<i data-lucide="info" class="w-5 h-5 text-blue-600"></i>';
            }
            
            toast.classList.remove('hidden');
            lucide.createIcons();

            // Auto dismiss success and info toasts after 6 seconds
            if (type !== 'error') {
                setTimeout(dismissToast, 6000);
            }
        }

        function dismissToast() {
            document.getElementById('status-toast').classList.add('hidden');
        }
    