
        // Utilities
        const currencyFormatter = new Intl.NumberFormat('en-IN', {
            style: 'currency',
            currency: 'INR',
            maximumFractionDigits: 0
        });

        const dateFormatter = new Intl.DateTimeFormat('en-IN', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });

        // Parse URL safely
        function getCustomerId() {
            const params = new URLSearchParams(window.location.search);
            // Check variations for robustness
            const id = params.get('customerId') || params.get('CustomerId') || params.get('customerid');
            return id;
        }

        // --- Core Application Logic ---
        document.addEventListener('DOMContentLoaded', () => {
            initDashboard();
        });

        async function initDashboard() {
            const customerId = getCustomerId();
            const identityEl = document.getElementById('customer-identity');

            if (!customerId) {
                identityEl.innerHTML = `No ID Provided <span class="bg-red-500 text-white text-[10px] px-2 py-0.5 rounded-full ml-2">Error</span>`;
                showError("Please provide a valid Customer ID in the URL. (e.g., ?customerId=1)");
                return;
            }

            identityEl.innerHTML = `#${customerId} <span class="bg-emerald-500/20 text-emerald-100 text-[10px] px-2 py-0.5 rounded border border-emerald-500/30 ml-2 tracking-wide">VERIFIED KYC</span>`;

            try {
                // 1. Try fetching from Live Server
                let data = null;
                try {
                    const response = await fetch(`http://localhost:8091/user/${customerId}/reports/outstanding-loans`);
                    if (response.ok) {
                        data = await response.json();
                    } else if (response.status === 404) {
                        throw new Error("404_NOT_FOUND");
                    } else {
                        throw new Error(`HTTP Error: ${response.status}`);
                    }
                } catch (fetchErr) {
                    console.warn("Live API fetch failed, falling back to mock data for Canvas preview purposes.", fetchErr);
                    
                    if (fetchErr.message === "404_NOT_FOUND") {
                        // Hard fail on 404 to trigger KYC error UI
                        throw fetchErr; 
                    }
                    
                    // 2. Fallback to exact POSTMAN mock data provided by user for UI viewing in isolated environments
                    data = getMockData();
                }

                // If data is empty or structurally missing, trigger error
                if (!data || !data.outstandingBalanceDetails || data.outstandingBalanceDetails.length === 0) {
                     throw new Error("EMPTY_RECORDS");
                }

                // Render Dashboard
                renderKPIs(data);
                renderUrgencyChart(data);
                renderGaugeChart(data);
                renderTable(data);

            } catch (error) {
                console.error("Dashboard Initialization Error:", error);
                
                let errorMsg = "We couldn't locate active loan records. Your KYC might still be pending approval, or the provided Customer ID does not exist.";
                if(error.message === "404_NOT_FOUND") {
                    errorMsg = "Customer profile not found or KYC is not approved. Please verify the ID and account status.";
                }

                showError(errorMsg);
            }
        }

        function showError(message) {
            document.getElementById('main-dashboard').style.display = 'none';
            const errorState = document.getElementById('error-state');
            errorState.classList.remove('hidden');
            document.getElementById('error-message').textContent = message;
        }

        // --- Render Functions ---

        function renderKPIs(data) {
            document.getElementById('kpi-total-outstanding').textContent = currencyFormatter.format(data.totalOutstandingBalance);
            document.getElementById('kpi-overdue-balance').textContent = currencyFormatter.format(data.overdueBalance);
            document.getElementById('kpi-total-repayment').textContent = currencyFormatter.format(data.totalRepaymentAmount);
        }

        let urgencyChartInstance = null;
        function renderUrgencyChart(data) {
            const ctx = document.getElementById('urgencyChart').getContext('2d');
            
            // Logic: Total Outstanding - Overdue = Healthy Future Principal
            const overdue = data.overdueBalance || 0;
            const healthy = Math.max(0, data.totalOutstandingBalance - overdue);

            // Update sub-stats
            document.getElementById('stat-healthy').textContent = currencyFormatter.format(healthy);
            document.getElementById('stat-overdue').textContent = currencyFormatter.format(overdue);

            if (urgencyChartInstance) urgencyChartInstance.destroy();

            urgencyChartInstance = new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: ['Urgent Overdue', 'Healthy Outstanding'],
                    datasets: [{
                        data: [overdue, healthy],
                        backgroundColor: ['#ef4444', '#3b82f6'], // Red, Blue
                        borderWidth: 0,
                        hoverOffset: 4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    cutout: '70%',
                    plugins: {
                        legend: {
                            position: 'bottom',
                            labels: {
                                padding: 20,
                                font: { family: 'Inter', size: 12 }
                            }
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    return ` ${context.label}: ${currencyFormatter.format(context.raw)}`;
                                }
                            }
                        }
                    }
                }
            });
        }

        let gaugeChartInstance = null;
        function renderGaugeChart(data) {
            const ctx = document.getElementById('gaugeChart').getContext('2d');
            
            const totalRepayment = data.totalRepaymentAmount || 0;
            const outstanding = data.totalOutstandingBalance || 0;
            
            // Prevent division by zero
            let paidAmount = Math.max(0, totalRepayment - outstanding);
            let percentage = 0;
            
            if (totalRepayment > 0) {
                percentage = (paidAmount / totalRepayment) * 100;
            }

            // Update text inside gauge
            document.getElementById('gauge-percentage').textContent = `${percentage.toFixed(1)}%`;

            if (gaugeChartInstance) gaugeChartInstance.destroy();

            gaugeChartInstance = new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: ['Cleared Debt', 'Remaining Balance'],
                    datasets: [{
                        data: [paidAmount, outstanding],
                        backgroundColor: ['#10b981', '#e2e8f0'], // Emerald Green, Light Gray
                        borderWidth: 0,
                        circumference: 180,
                        rotation: 270,
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    cutout: '80%',
                    plugins: {
                        legend: { display: false },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    return ` ${context.label}: ${currencyFormatter.format(context.raw)}`;
                                }
                            }
                        }
                    }
                }
            });
        }

        function renderTable(data) {
            const tbody = document.getElementById('portfolio-table-body');
            const items = data.outstandingBalanceDetails || [];
            
            tbody.innerHTML = '';

            items.forEach(row => {
                // Formatting Helpers
                const prinStr = currencyFormatter.format(row.principalAmount);
                const totalStr = currencyFormatter.format(row.totalRepaymentAmount);
                const outStr = currencyFormatter.format(row.outstandingAmount);
                const dateStr = row.nextDueDate ? dateFormatter.format(new Date(row.nextDueDate)) : '-';
                
                // Smart Badges for Urgency
                let urgencyBadge = '';
                if (row.daysOverdue > 0) {
                    urgencyBadge = `<span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold bg-red-100 text-red-800 border border-red-200">
                                        <svg class="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                                        ${row.daysOverdue} Days Overdue
                                    </span>`;
                } else {
                    urgencyBadge = `<span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                                        <svg class="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
                                        Current
                                    </span>`;
                }

                const tr = document.createElement('tr');
                tr.className = 'hover:bg-blue-50/50 transition-colors group';
                
                tr.innerHTML = `
                    <td class="py-4 px-6 whitespace-nowrap">
                        <div class="font-bold text-slate-800">APP-${row.applicationId}</div>
                        <div class="text-xs text-slate-500 mt-0.5 uppercase tracking-wide">${row.loanStatus}</div>
                    </td>
                    <td class="py-4 px-6 whitespace-nowrap">
                        ${urgencyBadge}
                    </td>
                    <td class="py-4 px-6 whitespace-nowrap text-right font-medium text-slate-600">
                        ${prinStr}
                    </td>
                    <td class="py-4 px-6 whitespace-nowrap text-right font-medium text-slate-600">
                        ${totalStr}
                    </td>
                    <td class="py-4 px-6 whitespace-nowrap text-right font-bold text-slate-800">
                        ${outStr}
                    </td>
                    <td class="py-4 px-6 whitespace-nowrap text-right font-medium text-slate-600">
                        ${dateStr}
                    </td>
                `;
                tbody.appendChild(tr);
            });
        }

        // Fallback Mock Data mapped perfectly from Postman Request
        function getMockData() {
            return {
                "outstandingBalanceDetails": [
                    {
                        "outstandingAmount": 80266.20,
                        "totalRepaymentAmount": 82559.52,
                        "nextDueDate": "2026-08-17",
                        "loanStatus": "APPROVED",
                        "applicationId": 276979,
                        "principalAmount": 60000.0,
                        "daysOverdue": 0
                    },
                    {
                        "outstandingAmount": 15000.00,
                        "totalRepaymentAmount": 20000.00,
                        "nextDueDate": "2026-04-10",
                        "loanStatus": "APPROVED",
                        "applicationId": 359846,
                        "principalAmount": 16000.0,
                        "daysOverdue": 15
                    }
                ],
                "totalRepaymentAmount": 102559.52,
                "overdueBalance": 15000.00,
                "totalOutstandingBalance": 95266.20
            };
        }
    