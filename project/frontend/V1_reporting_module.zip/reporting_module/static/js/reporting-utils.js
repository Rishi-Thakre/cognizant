/* ============================================================
   reporting-utils.js — Module 5 Shared Utilities
   Handles: API calls, date helpers, export, table rendering
   ============================================================ */

/* ---- API Base URL (adjust if needed) ---- */
const API_BASE = '';

/* ---- Generic Fetch Helper ---- */
async function fetchAPI(endpoint) {
    try {
        const res = await fetch(API_BASE + endpoint);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        return await res.json();
    } catch (err) {
        console.warn('API fetch failed, using demo data:', err.message);
        return null;
    }
}

/* ---- Date Helpers ---- */
function formatDate(dateStr) {
    if (!dateStr) return 'N/A';
    const d = new Date(dateStr);
    return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}

function formatCurrency(amount) {
    if (amount === null || amount === undefined) return '₹ 0.00';
    return '₹ ' + parseFloat(amount).toLocaleString('en-IN', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
}

function getTodayFormatted() {
    return new Date().toLocaleDateString('en-IN', {
        day: '2-digit', month: 'long', year: 'numeric'
    });
}

/* ---- Status Badge Helper ---- */
function getStatusBadge(status) {
    const map = {
        'APPROVED':  ['badge-approved',  'Approved'],
        'PENDING':   ['badge-pending',   'Pending'],
        'REJECTED':  ['badge-rejected',  'Rejected'],
        'PAID':      ['badge-completed', 'Paid'],
        'COMPLETED': ['badge-completed', 'Completed'],
        'ACTIVE':    ['badge-active',    'Active'],
        'OVERDUE':   ['badge-overdue',   'Overdue'],
        'PARTIAL':   ['badge-pending',   'Partial'],
    };
    const key = (status || '').toUpperCase();
    const [cls, label] = map[key] || ['badge-pending', status || 'Unknown'];
    return `<span class="badge-status ${cls}">${label}</span>`;
}

/* ---- Export to CSV ---- */
function exportTableToCSV(tableId, filename) {
    const table = document.getElementById(tableId);
    if (!table) return;
    let csv = [];
    const rows = table.querySelectorAll('tr');
    rows.forEach(row => {
        const cols = row.querySelectorAll('th, td');
        const rowData = [];
        cols.forEach(col => {
            let text = col.innerText.replace(/"/g, '""').trim();
            rowData.push(`"${text}"`);
        });
        csv.push(rowData.join(','));
    });
    const blob = new Blob([csv.join('\n')], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename || 'report.csv';
    a.click();
    URL.revokeObjectURL(url);
}

/* ---- Print Section ---- */
function printSection(sectionId) {
    const section = document.getElementById(sectionId);
    if (!section) return;
    const printWin = window.open('', '_blank');
    printWin.document.write(`
        <html><head>
        <title>NexusBank Report</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        <style>body{font-family:'Plus Jakarta Sans',sans-serif;padding:20px;}@media print{.no-print{display:none;}}</style>
        </head><body>${section.innerHTML}</body></html>
    `);
    printWin.document.close();
    printWin.focus();
    setTimeout(() => { printWin.print(); printWin.close(); }, 500);
}

/* ---- Toast Notification ---- */
function showToast(message, type = 'success') {
    const colors = { success: '#16a34a', danger: '#dc2626', info: '#2563eb', warning: '#ca8a04' };
    const toast = document.createElement('div');
    toast.style.cssText = `
        position: fixed; bottom: 28px; right: 28px; z-index: 9999;
        background: white; border-left: 4px solid ${colors[type] || colors.info};
        border-radius: 10px; padding: 14px 20px; box-shadow: 0 8px 24px rgba(15,23,42,0.12);
        font-family: 'Plus Jakarta Sans', sans-serif; font-size: 0.9rem;
        color: #334155; min-width: 260px; font-weight: 500;
        animation: slideIn 0.3s ease;
    `;
    toast.innerHTML = `<i class="bi bi-check-circle-fill me-2" style="color:${colors[type]};"></i>${message}`;
    document.body.appendChild(toast);
    setTimeout(() => { toast.style.opacity = '0'; toast.style.transition = 'opacity 0.3s'; setTimeout(() => toast.remove(), 300); }, 3000);
}

/* ---- Demo Data Sets ---- */
const DEMO_DATA = {
    adminLoanDashboard: {
        totalLoans: 342,
        totalDisbursed: 18500000,
        totalCollected: 12300000,
        pendingLoans: 28,
        approvedLoans: 289,
        rejectedLoans: 25,
        defaultRate: 3.8,
        avgLoanAmount: 54094
    },
    monthlyLoanData: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
        disbursed: [120000, 185000, 210000, 175000, 230000, 195000, 250000, 220000, 280000, 245000, 310000, 290000],
        repaid:    [80000,  110000, 145000, 130000, 160000, 155000, 180000, 175000, 210000, 195000, 240000, 220000]
    },
    loanTypeDistribution: {
        labels: ['Home Loan', 'Car Loan', 'Personal Loan', 'Business Loan', 'Education Loan'],
        values: [38, 22, 20, 12, 8]
    },
    repaymentTrend: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        onTime: [85, 88, 82, 90, 87, 92],
        late:   [10, 8,  12, 7,  9,  6 ],
        missed: [5,  4,  6,  3,  4,  2 ]
    },
    recentReports: [
        { id: 'RPT-2026-001', type: 'Loan Summary',      generatedOn: '28 May 2026', by: 'Admin', status: 'Completed', records: 342 },
        { id: 'RPT-2026-002', type: 'Repayment Report',  generatedOn: '27 May 2026', by: 'Admin', status: 'Completed', records: 1240 },
        { id: 'RPT-2026-003', type: 'Outstanding Loans', generatedOn: '26 May 2026', by: 'Admin', status: 'Completed', records: 53 },
        { id: 'RPT-2026-004', type: 'Customer Analysis', generatedOn: '25 May 2026', by: 'Admin', status: 'Completed', records: 200 },
        { id: 'RPT-2026-005', type: 'Default Report',    generatedOn: '24 May 2026', by: 'Admin', status: 'Completed', records: 13 },
    ],
    customerRepayments: [
        { date: '2026-05-10', loanId: 'LN-10021', desc: 'EMI Payment',    amount: 12500, status: 'PAID',    balance: 87500 },
        { date: '2026-04-10', loanId: 'LN-10021', desc: 'EMI Payment',    amount: 12500, status: 'PAID',    balance: 100000 },
        { date: '2026-03-10', loanId: 'LN-10021', desc: 'EMI Payment',    amount: 12500, status: 'PAID',    balance: 112500 },
        { date: '2026-02-10', loanId: 'LN-10021', desc: 'EMI Payment',    amount: 12500, status: 'PAID',    balance: 125000 },
        { date: '2026-01-10', loanId: 'LN-10021', desc: 'EMI Payment',    amount: 12500, status: 'PAID',    balance: 137500 },
        { date: '2025-12-10', loanId: 'LN-10021', desc: 'Late EMI',       amount: 12500, status: 'OVERDUE', balance: 150000 },
        { date: '2025-11-10', loanId: 'LN-10021', desc: 'EMI Payment',    amount: 12500, status: 'PAID',    balance: 162500 },
    ],
    customerLoans: [
        { loanId: 'LN-10021', type: 'Home Loan',     principal: 200000, outstanding: 87500,  emi: 12500, nextDue: '2026-06-10', status: 'ACTIVE' },
        { loanId: 'LN-10008', type: 'Car Loan',      principal: 80000,  outstanding: 0,      emi: 0,     nextDue: 'N/A',        status: 'COMPLETED' },
    ]
};
